package com.freza.dragonball

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("stream_url").orEmpty()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFF8A00))) {
                var error by remember { mutableStateOf("") }
                Column(
                    Modifier.fillMaxSize().background(Color(0xFF090909)),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (url.startsWith("https://")) {
                        val player = remember {
                            ExoPlayer.Builder(this@PlayerActivity).build().apply {
                                setMediaItem(MediaItem.fromUri(Uri.parse(url)))
                                prepare()
                                playWhenReady = true
                            }
                        }
                        DisposableEffect(player) {
                            onDispose { player.release() }
                        }
                        AndroidView(
                            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                        )
                        Text("مشغل FREZA • خيارات الصوت والترجمة تعتمد على مسارات المصدر", color = Color.LightGray,
                            modifier = Modifier.padding(16.dp))
                    } else {
                        Text("رابط الفيديو غير صالح. استخدم رابط HTTPS مرخصاً.", color = Color.White)
                    }
                }
            }
        }
    }
}
