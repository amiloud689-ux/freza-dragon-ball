package com.freza.dragonball

import android.content.Intent
import android.net.Uri
import android.os.Bundle\nimport android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*\nimport androidx.compose.ui.text.input.KeyboardType\nimport androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF191919)
private val Orange = Color(0xFFFF8A00)
private val Muted = Color(0xFFB8B8B8)

data class Anime(val title: String, val subtitle: String, val description: String, val url: String)

private val animeList = listOf(
    Anime("Dragon Ball", "1986 • السلسلة الأصلية", "بداية رحلة غوكو والبحث عن كرات التنين.", "https://www.toei-animation.com/"),
    Anime("Dragon Ball Z", "1989 • 291 حلقة", "مواجهات السايان وفريزا وسيل وماجين بو.", "https://www.crunchyroll.com/"),
    Anime("Dragon Ball GT", "1996 • سلسلة جانبية", "مغامرة جديدة مع غوكو وأصدقائه.", "https://www.crunchyroll.com/"),
    Anime("Dragon Ball Super", "2015 • 131 حلقة", "عوالم جديدة وتحولات ومعارك كونية.", "https://www.crunchyroll.com/"),
    Anime("Dragon Ball DAIMA", "2024 • سلسلة جديدة", "مغامرة غوكو وأصدقائه في عالم غامض.", "https://www.netflix.com/"),
    Anime("أفلام Dragon Ball", "مجموعة الأفلام", "اكتشف أفلام عالم دراغون بول عبر الناشرين الرسميين.", "https://www.toei-animation.com/")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FrezaApp() }
    }
}

@Composable
fun FrezaApp() {
    var selected by remember { mutableStateOf("الرئيسية") }
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    val context = LocalContext.current
    val filtered = animeList.filter { it.title.contains(query, ignoreCase = true) || it.subtitle.contains(query, ignoreCase = true) }
    var streamDialog by remember { mutableStateOf(false) }
    var streamUrl by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(selected == "الرئيسية", { selected = "الرئيسية" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected == "بحث", { selected = "بحث" },
                        icon = { Icon(Icons.Default.Search, null) }, label = { Text("بحث") })
                    NavigationBarItem(selected == "المفضلة", { selected = "المفضلة" },
                        icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("المفضلة") })
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                item {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp)) {
                        Text("FREZA", color = Orange, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                        Text("DRAGON BALL", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        Text("عالم الأنمي بين يديك", color = Muted, fontSize = 13.sp)
                    }
                }
                if (selected == "بحث") {
                    item {
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            placeholder = { Text("ابحث عن جزء من Dragon Ball") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Orange, unfocusedBorderColor = Color.DarkGray,
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White
                            )
                        )
                    }
                }
                if (selected == "الرئيسية") {
                    item {
                        Box(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(190.dp)
                                .background(Brush.linearGradient(listOf(Color(0xFF552400), Color(0xFF17100B), Color(0xFF262626))), RoundedCornerShape(22.dp))
                                .padding(20.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text("THE LEGEND RETURNS", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("قوة السايان\nلا تعرف الحدود", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                                Text("اكتشف عالم Dragon Ball", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item { SectionTitle("استكشف السلسلة") }
                } else if (selected == "المفضلة") {
                    item { SectionTitle("قائمتي المفضلة") }
                } else {
                    item { SectionTitle("نتائج البحث") }
                }

                val visible = when (selected) {
                    "المفضلة" -> animeList.filter { favorites.contains(it.title) }
                    "بحث" -> filtered
                    else -> animeList
                }
                if (visible.isEmpty()) {
                    item { Text("لا توجد نتائج بعد. أضف أعمالاً إلى المفضلة أو جرّب بحثاً آخر.", color = Muted, modifier = Modifier.padding(20.dp)) }
                }
                items(visible) { anime ->
                    AnimeCard(
                        anime = anime,
                        favorite = favorites.contains(anime.title),
                        onFavorite = {
                            favorites = if (favorites.contains(anime.title)) favorites - anime.title else favorites + anime.title
                        },
                        onOpen = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(anime.url))
                            context.startActivity(intent)
                        },
                        onPlay = { streamDialog = true }
                    )
                }
                item {
                    Column(Modifier.padding(18.dp)) {
                        Text("المشاهدة الرسمية", color = Orange, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("تختلف حقوق البث واللغات والجودة حسب البلد والمنصة. يفتح التطبيق صفحات الناشرين والمنصات الرسمية؛ لا يستضيف حلقات أو ينسخها.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            if (streamDialog) {
                AlertDialog(
                    onDismissRequest = { streamDialog = false },
                    title = { Text("تشغيل مصدر فيديو مرخّص") },
                    text = {
                        Column {
                            Text("ألصق رابط بث تملك حق استخدامه (مثل رابط HLS أو MP4). لا يحتوي التطبيق على حلقات جاهزة.", color = Muted)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = streamUrl, onValueChange = { streamUrl = it },
                                label = { Text("رابط الفيديو") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                                singleLine = true
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val intent = Intent(context, PlayerActivity::class.java)
                            intent.putExtra("stream_url", streamUrl.trim())
                            context.startActivity(intent)
                            streamDialog = false
                        }, enabled = streamUrl.startsWith("https://")) { Text("تشغيل", color = Orange) }
                    },
                    dismissButton = { TextButton(onClick = { streamDialog = false }) { Text("إلغاء") } }
                )
            }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 24.dp, bottom = 10.dp))
}

@Composable
fun AnimeCard(anime: Anime, favorite: Boolean, onFavorite: () -> Unit, onOpen: () -> Unit, onPlay: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(18.dp)).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 92.dp, height = 112.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF8B3900), Color(0xFF25150C), Color(0xFF101010))), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("龍", color = Orange, fontSize = 38.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(anime.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(anime.subtitle, color = Orange, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Text(anime.description, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onPlay, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)) {
                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(17.dp))
                    Text("تشغيل فيديو", fontSize = 11.sp)
                }
                IconButton(onClick = onOpen) {
                    Text("رسمي", color = Muted, fontSize = 10.sp)
                }
                IconButton(onClick = onFavorite) {
                    Icon(Icons.Default.Favorite, null, tint = if (favorite) Orange else Muted)
                }
            }
        }
    }
}
